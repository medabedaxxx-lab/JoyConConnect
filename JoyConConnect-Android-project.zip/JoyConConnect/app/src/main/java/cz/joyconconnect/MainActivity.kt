package cz.joyconconnect

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var events: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        fun heading(text: String, size: Float = 22f) = TextView(this).apply {
            this.text = text; textSize = size; setTypeface(null, Typeface.BOLD)
            setPadding(0, 12, 0, 10)
        }
        status = TextView(this).apply { textSize = 17f; setPadding(0, 8, 0, 12) }
        details = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 12) }
        events = TextView(this).apply { textSize = 15f; text = "Zatím žádné vstupy." }

        content.addView(heading("🎮 Joy-Con Connect"))
        content.addView(TextView(this).apply {
            text = "Připoj oba ovladače přes Bluetooth v nastavení Androidu. Tato aplikace pak zobrazí rozpoznaná zařízení a testuje tlačítka i páčky."
            textSize = 15f
        })
        content.addView(Button(this).apply {
            text = "Otevřít nastavení Bluetooth"
            setOnClickListener { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        })
        content.addView(Button(this).apply {
            text = "Obnovit seznam ovladačů"
            setOnClickListener { refreshDevices() }
        })
        content.addView(heading("Stav ovladačů"))
        content.addView(status)
        content.addView(details)
        content.addView(heading("Test tlačítek a páček"))
        content.addView(TextView(this).apply {
            text = "Stiskni tlačítko nebo pohni páčkou na připojeném Joy-Conu. Události se zobrazí níže."
            textSize = 14f
        })
        content.addView(events)
        root.addView(scroll)
        setContentView(root)
        refreshDevices()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshDevices()
    }

    private fun refreshDevices() {
        val devices = InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }
        val gamepads = devices.filter {
            (it.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (it.sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        }
        status.text = if (gamepads.isEmpty()) {
            "⚪ Zatím nebyl rozpoznán žádný gamepad."
        } else {
            "🟢 Rozpoznáno zařízení: ${gamepads.size}"
        }
        details.text = if (gamepads.isEmpty()) {
            "Tip: podrž malé párovací tlačítko SYNC na Joy-Conu, v Bluetooth vyber „Joy-Con (L)“ a „Joy-Con (R)“ a spáruj je postupně."
        } else gamepads.joinToString("\n\n") { d ->
            "• ${d.name}\nID: ${d.id}\nTyp: ${if ((d.sources and InputDevice.SOURCE_GAMEPAD) != 0) "Gamepad" else "Joystick"}"
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        events.text = "Stisknuto: ${KeyEvent.keyCodeToString(keyCode)}\nZařízení: ${event.device?.name ?: "neznámé"}"
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        events.text = "Uvolněno: ${KeyEvent.keyCodeToString(keyCode)}\nZařízení: ${event.device?.name ?: "neznámé"}"
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK &&
            event.action == MotionEvent.ACTION_MOVE) {
            val device = event.device
            val axes = listOf(MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z,
                MotionEvent.AXIS_RZ, MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y)
            val values = axes.map { axis ->
                val name = MotionEvent.axisToString(axis)
                val value = event.getAxisValue(axis)
                if (value != 0f) "$name: %.2f".format(value) else null
            }.filterNotNull()
            events.text = "Páčka – ${device?.name ?: "ovladač"}\n" +
                (values.joinToString("\n").ifEmpty { "Pohyb zachycen (osa v neutrální poloze)." })
            return true
        }
        return super.onGenericMotionEvent(event)
    }
}
