# Joy-Con Connect (Android)

Jednoduchá Android aplikace pro rozpoznání Nintendo Joy-Conů spárovaných systémem Android a testování tlačítek/páček.

## Spuštění
1. Otevři Bluetooth v Androidu.
2. Na Joy-Conu podrž tlačítko SYNC na boku, dokud nezačnou blikat LED.
3. V telefonu vyber Joy-Con (L), spáruj jej. Stejně spáruj Joy-Con (R).
4. Otevři Joy-Con Connect a klepni na „Obnovit seznam ovladačů“.
5. Stiskem tlačítek nebo pohybem páček ověř vstupy.

## Sestavení APK
Otevři složku projektu v Android Studio (Hedgehog nebo novější), nech Gradle dokončit synchronizaci a zvol **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Výsledný APK najdeš v `app/build/outputs/apk/debug/`.

Poznámky: Android a konkrétní hra rozhodují o tom, zda lze oba Joy-Cony používat současně jako jeden kombinovaný ovladač. Tato první verze zobrazuje systémem rozpoznaná vstupní zařízení a testuje jejich události; neprovádí vlastní Bluetooth párování.
